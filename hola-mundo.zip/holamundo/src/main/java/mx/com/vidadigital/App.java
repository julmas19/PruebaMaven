package mx.com.vidadigital;

/**
 * Hola mundo
 *
 */
public class App 
{	public static void main(String[] args)
    {	System.out.println("Hola mundo");
    }
}
